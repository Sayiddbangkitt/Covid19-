<?php 
	$con = mysqli_connect("localhost","id13274148_covid","23Mei2003-sayid","id13274148_db_covid");
 ?>